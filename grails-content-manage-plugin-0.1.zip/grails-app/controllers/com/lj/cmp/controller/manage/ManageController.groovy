package com.lj.cmp.controller.manage

class ManageController {

    def index() {

        render(view:"/cmp/manage/index");
    }
}
